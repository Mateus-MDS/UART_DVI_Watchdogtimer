#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "pico/multicore.h"
#include "pico/bootrom.h" 
#include "pico/sem.h"
#include "pico/stdlib.h"
#include "hardware/clocks.h"
#include "hardware/irq.h"
#include "hardware/sync.h"
#include "hardware/gpio.h"
#include "hardware/vreg.h"
#include "hardware/structs/bus_ctrl.h"
#include "hardware/structs/ssi.h"
#include "hardware/dma.h"
#include "hardware/uart.h"      // Adicionado para UART
#include "hardware/watchdog.h"  // Adicionado para Watchdog
#include "dvi.h"
#include "dvi_serialiser.h"
#include "./include/common_dvi_pin_configs.h"
#include "tmds_encode_font_2bpp.h"

// Inclui a fonte original
#include "./assets/font_8x8.h"

// --- CONFIGURAÇÕES DVI E FONTE ---
#define FONT_CHAR_WIDTH 8
#define FONT_CHAR_HEIGHT 24         
#define FONT_ORIGINAL_HEIGHT 8      
#define FONT_N_CHARS 95
#define FONT_FIRST_ASCII 32

#define FRAME_WIDTH 640
#define FRAME_HEIGHT 480

// Tensão alta para estabilidade no overclock (252MHz)
#define VREG_VSEL VREG_VOLTAGE_1_30 
#define DVI_TIMING dvi_timing_640x480p_60hz

// --- CONFIGURAÇÕES DE UART E WATCHDOG ---
#define UART_ID uart0
#define BAUD_RATE 115200
#define UART_TX_PIN 0
#define UART_RX_PIN 1  // Solicitado na tarefa: RX no GP1

// Tempo do Watchdog (ms). 3000ms é seguro para não resetar durante o boot do vídeo
#define WDT_TIMEOUT_MS 3000 

struct dvi_inst dvi0;

// Configuração da grelha de texto
#define CHAR_COLS (FRAME_WIDTH / FONT_CHAR_WIDTH)
#define CHAR_ROWS (FRAME_HEIGHT / FONT_CHAR_HEIGHT) 

// Buffers de vídeo
#define COLOUR_PLANE_SIZE_WORDS (CHAR_ROWS * CHAR_COLS * 4 / 32)
char charbuf[CHAR_ROWS * CHAR_COLS];
uint32_t colourbuf[3 * COLOUR_PLANE_SIZE_WORDS];

// Buffer de fonte na RAM
uint8_t font_ram[FONT_N_CHARS * FONT_ORIGINAL_HEIGHT];

// Variável compartilhada para checagem de saúde do Core 1
volatile uint32_t core1_heartbeat = 0;

// Botão B (Usado agora para SIMULAR FALHA)
#define botaoB 6

// Funções auxiliares de desenho
static inline void set_char(uint x, uint y, char c) {
    if (x >= CHAR_COLS || y >= CHAR_ROWS) return;
    charbuf[x + y * CHAR_COLS] = c;
}

static inline void set_colour(uint x, uint y, uint8_t fg, uint8_t bg) {
    if (x >= CHAR_COLS || y >= CHAR_ROWS) return;
    uint char_index = x + y * CHAR_COLS;
    uint bit_index = char_index % 8 * 4;
    uint word_index = char_index / 8;
    for (int plane = 0; plane < 3; ++plane) {
        uint32_t fg_bg_combined = (fg & 0x3) | (bg << 2 & 0xc);
        colourbuf[word_index] = (colourbuf[word_index] & ~(0xfu << bit_index)) | (fg_bg_combined << bit_index);
        fg >>= 2;
        bg >>= 2;
        word_index += COLOUR_PLANE_SIZE_WORDS;
    }
}

// Limpa uma linha específica com espaços
void clear_line(int y, uint8_t fg, uint8_t bg) {
    for (int x = 1; x < CHAR_COLS - 1; ++x) {
        set_char(x, y, ' ');
        set_colour(x, y, fg, bg);
    }
}

// Escreve texto centralizado
void write_centered_text(int y, const char *text, uint8_t fg, uint8_t bg) {
    int len = strlen(text);
    int start_x = (CHAR_COLS - len) / 2;
    for (int i = 0; i < len; ++i) {
        set_char(start_x + i, y, text[i]);
        set_colour(start_x + i, y, fg, bg);
    }
}

void draw_border() {
    const uint8_t fg = 0x15; // Cinza
    const uint8_t bg = 0x0c; // Verde
    
    for (uint x = 0; x < CHAR_COLS; ++x) {
        set_char(x, 0, '-'); set_colour(x, 0, fg, bg);
        set_char(x, CHAR_ROWS - 1, '-'); set_colour(x, CHAR_ROWS - 1, fg, bg);
    }
    for (uint y = 0; y < CHAR_ROWS; ++y) {
        set_char(0, y, '|'); set_colour(0, y, fg, bg);
        set_char(CHAR_COLS - 1, y, '|'); set_colour(CHAR_COLS - 1, y, fg, bg);
    }
    set_char(0, 0, '+'); set_char(CHAR_COLS - 1, 0, '+');
    set_char(0, CHAR_ROWS - 1, '+'); set_char(CHAR_COLS - 1, CHAR_ROWS - 1, '+');
}

// --- CORE 1: RENDERIZAÇÃO DVI ---
void core1_main() {
    dvi_register_irqs_this_core(&dvi0, DMA_IRQ_0);
    dvi_start(&dvi0);

    const uint32_t colour_step = COLOUR_PLANE_SIZE_WORDS / CHAR_ROWS;

    while (true) {
        // SINAL DE VIDA: Incrementa contador a cada frame
        // Se este loop travar (video falhar), o contador para.
        core1_heartbeat++;

        uint current_char_row_idx = 0; 
        uint current_font_row = 0;      
        uint repeat_counter = 0;        

        const uint8_t *charbuf_ptr = (const uint8_t *)charbuf;
        uint32_t *colour_ptr_base = colourbuf; 

        for (uint y = 0; y < FRAME_HEIGHT; ++y) {
            uint32_t *tmdsbuf;
            queue_remove_blocking(&dvi0.q_tmds_free, &tmdsbuf);

            const uint8_t *font_row_base = &font_ram[current_font_row * FONT_N_CHARS] - FONT_FIRST_ASCII;

            for (int plane = 0; plane < 3; ++plane) {
                tmds_encode_font_2bpp(
                    charbuf_ptr,
                    colour_ptr_base + (plane * COLOUR_PLANE_SIZE_WORDS),
                    tmdsbuf + plane * (FRAME_WIDTH / DVI_SYMBOLS_PER_WORD),
                    FRAME_WIDTH,
                    font_row_base
                );
            }
            queue_add_blocking(&dvi0.q_tmds_valid, &tmdsbuf);

            repeat_counter++;
            if (repeat_counter >= 3) { 
                repeat_counter = 0;
                current_font_row++; 
                if (current_font_row >= 8) { 
                    current_font_row = 0;
                    current_char_row_idx++; 
                    charbuf_ptr += CHAR_COLS;
                    colour_ptr_base += colour_step;
                }
            }
        }
    }
}

// --- CORE 0: LÓGICA PRINCIPAL (UART + WATCHDOG) ---
int __not_in_flash("main") main() {
    // 1. Diagnóstico de Reset: Checa o motivo ANTES de qualquer coisa
    bool wdt_caused_reset = watchdog_caused_reboot();

    vreg_set_voltage(VREG_VSEL);
    sleep_ms(10);
    set_sys_clock_khz(DVI_TIMING.bit_clk_khz, true);

    // Copia fonte para RAM
    memcpy(font_ram, font_8x8, FONT_N_CHARS * FONT_ORIGINAL_HEIGHT);

    // --- INICIALIZAÇÃO DE PERIFÉRICOS ---
    stdio_init_all();
    
    // Inicializa Botão (Simulador de Falha)
    gpio_init(botaoB);
    gpio_set_dir(botaoB, GPIO_IN);
    gpio_pull_up(botaoB);

    // Inicializa UART
    uart_init(UART_ID, BAUD_RATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);

    // Inicializa DVI
    dvi0.timing = &DVI_TIMING;
    dvi0.ser_cfg = picodvi_dvi_cfg;
    dvi_init(&dvi0, next_striped_spin_lock_num(), next_striped_spin_lock_num());

    // Limpa tela
    for (uint i = 0; i < CHAR_ROWS * CHAR_COLS; ++i) charbuf[i] = ' ';
    memset(colourbuf, 0, sizeof(colourbuf));
    draw_border();

    // Lança Core 1
    hw_set_bits(&bus_ctrl_hw->priority, BUSCTRL_BUS_PRIORITY_PROC1_BITS);
    multicore_launch_core1(core1_main);

    // --- HABILITA WATCHDOG ---
    // Timeout de 3000ms. Se não for alimentado nesse tempo, reseta.
    watchdog_enable(WDT_TIMEOUT_MS, 1);

    // Variáveis locais
    uint32_t last_core1_beat = 0;
    char uart_buffer[64] = "Aguardando dados...";
    uint8_t buffer_idx = 0;
    
    // Exibe o motivo do último reset (Diagnóstico)
    if (wdt_caused_reset) {
        write_centered_text(2, "ALERTA: RECUPERADO DE FALHA (WATCHDOG RESET)", 0x30, 0x03); // Vermelho
    } else {
        write_centered_text(2, "SISTEMA INICIADO NORMALMENTE (POWER ON)", 0x0c, 0x00); // Verde
    }

    write_centered_text(4, "Pressione Botao B para SIMULAR TRAVAMENTO", 0x3f, 0x00);

    while (true) {
        // 1. LEITURA UART (Recebe caracteres do Transmissor)
        while (uart_is_readable(UART_ID)) {
            char c = uart_getc(UART_ID);
            if (c == '\n' || c == '\r') {
                uart_buffer[buffer_idx] = '\0'; // Finaliza string
                buffer_idx = 0; // Reseta buffer
                
                // Atualiza tela com mensagem recebida
                clear_line(10, 0x00, 0x00);
                char msg_formatted[80];
                sprintf(msg_formatted, "Recebido UART: %s", uart_buffer);
                write_centered_text(10, msg_formatted, 0x3f, 0x30); // Amarelo/Azul
                
            } else if (buffer_idx < 63) {
                uart_buffer[buffer_idx++] = c;
            }
        }

        // 2. SIMULAÇÃO DE FALHA (Requisito da Tarefa)
        if (!gpio_get(botaoB)) {
            // Se botão pressionado, entra em loop infinito
            // O Watchdog NÃO será alimentado e vai resetar o sistema em 3s
            write_centered_text(15, "!!! TRAVAMENTO SIMULADO !!!", 0x3f, 0x30);
            write_centered_text(16, "Aguardando Watchdog Reset...", 0x3f, 0x30);
            while(true) {
                // Loop infinito: Core 0 travou.
                // Watchdog vai disparar.
                tight_loop_contents(); 
            }
        }

        // 3. LÓGICA DE ALIMENTAÇÃO DO WATCHDOG (Requisito Multicore)
        // Só alimenta o cão se o Core 1 estiver vivo (atualizando core1_heartbeat)
        if (core1_heartbeat != last_core1_beat) {
            watchdog_update(); // Alimenta o Watchdog! Tudo ok.
            last_core1_beat = core1_heartbeat;
        } 
        // Se core1_heartbeat parar de mudar (vídeo travou), 
        // o 'if' acima falha, o watchdog não é atualizado, e o sistema reseta.

        sleep_ms(10);
    }
}